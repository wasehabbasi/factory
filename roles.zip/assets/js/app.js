function toggleSidebar() {
  document.querySelector('.sidebar').classList.toggle('open');
}
